<img width="1434" height="796" alt="Screenshot 2026-05-25 162215" src="https://github.com/user-attachments/assets/62c4a014-9109-4803-b2c7-0dfa70e31680" />
<img width="1244" height="636" alt="Screenshot 2026-05-25 162143" src="https://github.com/user-attachments/assets/cacc0376-e964-4391-a84d-7db555ae0030" />
<img width="1122" height="866" alt="Screenshot 2026-05-25 162058" src="https://github.com/user-attachments/assets/fa7ab276-bb18-4c8b-81bc-e8a52ee8c9de" />
<img width="1802" height="808" alt="Screenshot 2026-05-25 161826" src="https://github.com/user-attachments/assets/57ec66e0-b79e-407b-863f-607f7b687ec6" />
<img width="1890" height="860" alt="Screenshot 2026-05-25 141815" src="https://github.com/user-attachments/assets/45cb6a8b-d858-46a0-9506-245aad6ac73b" />
# Restaurant Website 🍽️

A modern and responsive restaurant website built using Next.js, React, HTML, CSS, and JavaScript with the help of AI-powered development tools like v0.dev.

## Features

- Responsive design
- Modern UI/UX
- Interactive sections
- Mobile-friendly layout
- Fast performance

## Tech Stack

- Next.js
- React
- HTML
- CSS
- JavaScript
- v0.dev

## Getting Started

First, install dependencies:

```bash
npm install
```

Run the development server:

```bash
npm run dev
```

Open http://localhost:3000 in your browser to see the result.

## What I Learned

- React and Next.js basics
- Component-based frontend development
- Responsive website design
- GitHub project management
- AI-assisted web development

## Future Improvements

- Add online food ordering
- Add backend integration
- Improve animations
- Add dark mode

## Author

Created by Indhusrikancha
