"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Star, Send, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

export default function FeedbackPage() {
  const [submitted, setSubmitted] = useState(false)
  const [rating, setRating] = useState(0)
  const [hoverRating, setHoverRating] = useState(0)
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    visitType: "dine-in",
    foodRating: "",
    serviceRating: "",
    ambienceRating: "",
    feedback: "",
    suggestions: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // Build WhatsApp message
    const message = `*Customer Feedback - VRR Hotel*\n\n*Customer:* ${formData.name}\n*Phone:* ${formData.phone}\n*Email:* ${formData.email || "Not provided"}\n*Visit Type:* ${formData.visitType}\n\n*Ratings:*\nOverall: ${rating}/5 stars\nFood Quality: ${formData.foodRating}/5\nService: ${formData.serviceRating}/5\nAmbience: ${formData.ambienceRating}/5\n\n*Feedback:*\n${formData.feedback}\n\n*Suggestions:*\n${formData.suggestions || "None"}`
    
    const whatsappUrl = `https://wa.me/919281433449?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
    
    setSubmitted(true)
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full text-center">
          <CardContent className="p-8">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <h2 className="font-heading text-2xl font-bold text-primary mb-2">
              Thank You!
            </h2>
            <p className="text-muted-foreground mb-6">
              Your feedback has been submitted successfully. We truly appreciate you taking the time to share your experience with us.
            </p>
            <div className="flex flex-col gap-3">
              <Link href="/">
                <Button className="w-full">Back to Home</Button>
              </Link>
              <Button 
                variant="outline" 
                onClick={() => {
                  setSubmitted(false)
                  setFormData({
                    name: "",
                    phone: "",
                    email: "",
                    visitType: "dine-in",
                    foodRating: "",
                    serviceRating: "",
                    ambienceRating: "",
                    feedback: "",
                    suggestions: "",
                  })
                  setRating(0)
                }}
              >
                Submit Another Feedback
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-primary shadow-md">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2 text-white">
              <ArrowLeft className="h-5 w-5" />
              <span className="font-medium">Back to Home</span>
            </Link>
            <h1 className="font-heading text-xl font-bold text-white">
              Feedback
            </h1>
            <div className="w-24" />
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="py-12 bg-gradient-to-br from-primary via-primary to-accent">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-white mb-4">
            We Value Your Feedback
          </h2>
          <p className="text-white/80 max-w-2xl mx-auto">
            Your opinion matters to us! Help us serve you better by sharing your dining experience at VRR Hotel.
          </p>
        </div>
      </section>

      {/* Feedback Form */}
      <section className="py-12">
        <div className="mx-auto max-w-2xl px-4 sm:px-6 lg:px-8">
          <Card>
            <CardContent className="p-6 sm:p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Personal Info */}
                <div>
                  <h3 className="font-heading font-semibold text-primary mb-4">
                    Your Information
                  </h3>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Name *</Label>
                      <Input
                        id="name"
                        placeholder="Your name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone *</Label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="Phone number"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        required
                      />
                    </div>
                  </div>
                  <div className="mt-4 space-y-2">
                    <Label htmlFor="email">Email (Optional)</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    />
                  </div>
                </div>

                {/* Visit Type */}
                <div>
                  <h3 className="font-heading font-semibold text-primary mb-4">
                    How did you visit us?
                  </h3>
                  <RadioGroup
                    value={formData.visitType}
                    onValueChange={(value) => setFormData({ ...formData, visitType: value })}
                    className="flex flex-wrap gap-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="dine-in" id="dine-in" />
                      <Label htmlFor="dine-in">Dine-in</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="takeaway" id="takeaway" />
                      <Label htmlFor="takeaway">Takeaway</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="delivery" id="delivery" />
                      <Label htmlFor="delivery">Delivery</Label>
                    </div>
                  </RadioGroup>
                </div>

                {/* Overall Rating */}
                <div>
                  <h3 className="font-heading font-semibold text-primary mb-4">
                    Overall Experience *
                  </h3>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        onMouseEnter={() => setHoverRating(star)}
                        onMouseLeave={() => setHoverRating(0)}
                        className="focus:outline-none"
                      >
                        <Star
                          className={`h-10 w-10 transition-colors ${
                            star <= (hoverRating || rating)
                              ? "text-secondary fill-secondary"
                              : "text-muted-foreground"
                          }`}
                        />
                      </button>
                    ))}
                    <span className="ml-2 text-lg font-medium text-primary">
                      {rating > 0 && `${rating}/5`}
                    </span>
                  </div>
                </div>

                {/* Detailed Ratings */}
                <div>
                  <h3 className="font-heading font-semibold text-primary mb-4">
                    Rate Different Aspects
                  </h3>
                  <div className="space-y-4">
                    {[
                      { key: "foodRating", label: "Food Quality" },
                      { key: "serviceRating", label: "Service" },
                      { key: "ambienceRating", label: "Ambience" },
                    ].map(({ key, label }) => (
                      <div key={key} className="flex items-center justify-between">
                        <Label className="text-sm">{label}</Label>
                        <div className="flex gap-1">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <button
                              key={star}
                              type="button"
                              onClick={() => setFormData({ ...formData, [key]: star.toString() })}
                              className="focus:outline-none"
                            >
                              <Star
                                className={`h-6 w-6 transition-colors ${
                                  star <= Number(formData[key as keyof typeof formData] || 0)
                                    ? "text-secondary fill-secondary"
                                    : "text-muted-foreground"
                                }`}
                              />
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Feedback Text */}
                <div className="space-y-2">
                  <Label htmlFor="feedback">Your Feedback *</Label>
                  <Textarea
                    id="feedback"
                    placeholder="Tell us about your experience..."
                    value={formData.feedback}
                    onChange={(e) => setFormData({ ...formData, feedback: e.target.value })}
                    rows={4}
                    required
                  />
                </div>

                {/* Suggestions */}
                <div className="space-y-2">
                  <Label htmlFor="suggestions">Suggestions for Improvement (Optional)</Label>
                  <Textarea
                    id="suggestions"
                    placeholder="Any suggestions to make your next visit better?"
                    value={formData.suggestions}
                    onChange={(e) => setFormData({ ...formData, suggestions: e.target.value })}
                    rows={3}
                  />
                </div>

                {/* Submit Button */}
                <Button 
                  type="submit" 
                  size="lg" 
                  className="w-full"
                  disabled={!formData.name || !formData.phone || !formData.feedback || rating === 0}
                >
                  <Send className="h-5 w-5 mr-2" />
                  Submit Feedback
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Contact Info */}
      <section className="py-10 bg-muted">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-muted-foreground mb-2">
            Have immediate concerns? Reach out to us directly:
          </p>
          <Link 
            href="tel:+919281433449" 
            className="text-secondary font-semibold hover:underline"
          >
            +91 92814 33449
          </Link>
        </div>
      </section>
    </div>
  )
}
