import type { Metadata } from 'next'
import { Poppins, Inter } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const poppins = Poppins({ 
  subsets: ["latin"],
  weight: ['400', '500', '600', '700'],
  variable: '--font-heading'
})

const inter = Inter({ 
  subsets: ["latin"],
  variable: '--font-sans'
})

export const metadata: Metadata = {
  title: 'VRR Hotel | Affordable Taste. Memorable Experience.',
  description: 'VRR Hotel is a clean and welcoming restaurant in Nellore known for tasty tiffins, veg and non-veg dishes, affordable pricing, and comfortable ambience.',
  keywords: ['VRR Hotel', 'Nellore restaurant', 'South Indian food', 'affordable dining', 'family restaurant'],
  openGraph: {
    title: 'VRR Hotel | Affordable Taste. Memorable Experience.',
    description: 'Experience delicious South Indian cuisine in a welcoming atmosphere at VRR Hotel, Nellore.',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="bg-background">
      <body className={`${poppins.variable} ${inter.variable} font-sans antialiased`}>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
