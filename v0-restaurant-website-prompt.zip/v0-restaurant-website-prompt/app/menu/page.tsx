"use client"

import { useState } from "react"
import Link from "next/link"
import { menuData, getTotalMenuItems } from "@/lib/menu-data"
import { Button } from "@/components/ui/button"
import { ChevronLeft, Search, Leaf, Drumstick } from "lucide-react"

type FilterType = "all" | "veg" | "non-veg"

export default function MenuPage() {
  const [activeSection, setActiveSection] = useState<string | null>(null)
  const [filter, setFilter] = useState<FilterType>("all")
  const [searchQuery, setSearchQuery] = useState("")

  const totalItems = getTotalMenuItems()

  const filteredData = menuData.map(section => ({
    ...section,
    categories: section.categories.map(category => ({
      ...category,
      items: category.items.filter(item => {
        const matchesFilter = 
          filter === "all" || 
          (filter === "veg" && item.isVeg) || 
          (filter === "non-veg" && !item.isVeg)
        const matchesSearch = 
          searchQuery === "" || 
          item.name.toLowerCase().includes(searchQuery.toLowerCase())
        return matchesFilter && matchesSearch
      })
    })).filter(category => category.items.length > 0)
  })).filter(section => section.categories.length > 0)

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId)
    const element = document.getElementById(sectionId)
    if (element) {
      const offset = 120
      const elementPosition = element.getBoundingClientRect().top
      const offsetPosition = elementPosition + window.pageYOffset - offset
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      })
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-primary text-primary-foreground shadow-lg">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2 text-primary-foreground hover:text-secondary transition-colors">
              <ChevronLeft className="h-5 w-5" />
              <span className="font-medium">Back</span>
            </Link>
            <div className="text-center">
              <h1 className="font-heading text-xl font-bold">Our Menu</h1>
              <p className="text-xs text-primary-foreground/70">{totalItems}+ Items</p>
            </div>
            <div className="w-20" />
          </div>
        </div>
      </header>

      {/* Search and Filter Bar */}
      <div className="sticky top-16 z-40 bg-card border-b border-border shadow-sm">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-4">
          {/* Search */}
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search dishes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-secondary focus:border-transparent"
            />
          </div>

          {/* Filter Buttons */}
          <div className="flex gap-2 mb-4">
            <Button
              size="sm"
              variant={filter === "all" ? "default" : "outline"}
              onClick={() => setFilter("all")}
              className={filter === "all" ? "bg-secondary text-secondary-foreground" : ""}
            >
              All
            </Button>
            <Button
              size="sm"
              variant={filter === "veg" ? "default" : "outline"}
              onClick={() => setFilter("veg")}
              className={filter === "veg" ? "bg-green-600 text-white hover:bg-green-700" : "text-green-600 border-green-600 hover:bg-green-50"}
            >
              <Leaf className="h-4 w-4 mr-1" />
              Veg
            </Button>
            <Button
              size="sm"
              variant={filter === "non-veg" ? "default" : "outline"}
              onClick={() => setFilter("non-veg")}
              className={filter === "non-veg" ? "bg-red-600 text-white hover:bg-red-700" : "text-red-600 border-red-600 hover:bg-red-50"}
            >
              <Drumstick className="h-4 w-4 mr-1" />
              Non-Veg
            </Button>
          </div>

          {/* Section Navigation */}
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {menuData.map((section) => (
              <button
                key={section.id}
                onClick={() => scrollToSection(section.id)}
                className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  activeSection === section.id
                    ? "bg-secondary text-secondary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                {section.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Menu Content */}
      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        {filteredData.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-muted-foreground text-lg">No items found matching your criteria.</p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => { setFilter("all"); setSearchQuery(""); }}
            >
              Clear Filters
            </Button>
          </div>
        ) : (
          <div className="space-y-12">
            {filteredData.map((section) => (
              <section key={section.id} id={section.id}>
                <h2 className="font-heading text-2xl font-bold text-primary mb-6 pb-2 border-b-2 border-secondary">
                  {section.name}
                </h2>
                <div className="space-y-8">
                  {section.categories.map((category) => (
                    <div key={category.id}>
                      <h3 className="font-heading text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                        {category.items[0]?.isVeg ? (
                          <span className="inline-flex items-center justify-center w-5 h-5 border-2 border-green-600 rounded">
                            <span className="w-2.5 h-2.5 bg-green-600 rounded-full" />
                          </span>
                        ) : (
                          <span className="inline-flex items-center justify-center w-5 h-5 border-2 border-red-600 rounded">
                            <span className="w-2.5 h-2.5 bg-red-600 rounded-full" />
                          </span>
                        )}
                        {category.name}
                      </h3>
                      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                        {category.items.map((item, index) => (
                          <div
                            key={`${category.id}-${index}`}
                            className="flex items-start gap-3 p-4 rounded-lg bg-card border border-border hover:border-secondary hover:shadow-md transition-all duration-200"
                          >
                            <span className={`mt-1 inline-flex items-center justify-center w-4 h-4 border-2 rounded flex-shrink-0 ${
                              item.isVeg ? "border-green-600" : "border-red-600"
                            }`}>
                              <span className={`w-2 h-2 rounded-full ${
                                item.isVeg ? "bg-green-600" : "bg-red-600"
                              }`} />
                            </span>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-2">
                                <h4 className="font-medium text-foreground text-sm leading-tight">
                                  {item.name}
                                </h4>
                                <span className="font-semibold text-secondary text-sm whitespace-nowrap">
                                  ₹{item.price}
                                </span>
                              </div>
                              {item.description && (
                                <p className="text-xs text-muted-foreground mt-1">
                                  {item.description}
                                </p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            ))}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-8 mt-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-sm text-primary-foreground/70">
            FSSAI Lic. No. 10123009000019
          </p>
          <p className="font-heading font-bold text-lg mt-2">VRR Hotel</p>
          <p className="text-sm text-primary-foreground/70 mt-1">
            Nellore &apos;s Favorite Family Restaurant
          </p>
          <Link href="/">
            <Button variant="outline" className="mt-4 border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground">
              Back to Home
            </Button>
          </Link>
        </div>
      </footer>
    </div>
  )
}
