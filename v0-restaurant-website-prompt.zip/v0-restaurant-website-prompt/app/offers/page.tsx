"use client"

import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Clock, Tag, Percent, Gift, Utensils } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const offers = [
  {
    id: 1,
    title: "Family Feast Combo",
    description: "4 Meals + 4 Drinks + 2 Desserts at a special price. Perfect for family dining!",
    originalPrice: 1200,
    offerPrice: 899,
    discount: "25% OFF",
    validTill: "Valid till 31st Dec 2024",
    tag: "Best Seller",
    image: "/images/family-dining.jpg",
  },
  {
    id: 2,
    title: "Breakfast Special",
    description: "2 Idli + 2 Vada + 1 Dosa + Filter Coffee. Start your day with authentic South Indian breakfast!",
    originalPrice: 180,
    offerPrice: 129,
    discount: "28% OFF",
    validTill: "Daily 6 AM - 10 AM",
    tag: "Morning Deal",
    image: "/images/idli.jpg",
  },
  {
    id: 3,
    title: "Student Special",
    description: "Show your student ID and get special discount on meals. Valid on all days!",
    originalPrice: 150,
    offerPrice: 99,
    discount: "34% OFF",
    validTill: "Valid with Student ID",
    tag: "Students Only",
    image: "/images/veg-meal.jpg",
  },
  {
    id: 4,
    title: "Biryani Bonanza",
    description: "Order any 2 Biryanis and get 1 Raita + 2 Soft Drinks FREE!",
    originalPrice: 500,
    offerPrice: 399,
    discount: "20% OFF",
    validTill: "Weekends Only",
    tag: "Weekend Special",
    image: "/images/fried-rice.jpg",
  },
  {
    id: 5,
    title: "Noodles Mania",
    description: "Buy 2 Noodles/Fried Rice and get 1 Starter FREE. Choose from our wide variety!",
    originalPrice: 380,
    offerPrice: 299,
    discount: "21% OFF",
    validTill: "All Week",
    tag: "Popular",
    image: "/images/noodles.jpg",
  },
  {
    id: 6,
    title: "Dosa Festival",
    description: "Any 3 Dosas + 3 Chutneys + Sambar at an unbeatable price!",
    originalPrice: 270,
    offerPrice: 199,
    discount: "26% OFF",
    validTill: "Limited Time",
    tag: "New",
    image: "/images/dosa.jpg",
  },
]

const quickDeals = [
  {
    icon: Gift,
    title: "Birthday Special",
    description: "Free dessert on your birthday! Just show valid ID proof.",
  },
  {
    icon: Utensils,
    title: "Group Booking",
    description: "10% off for groups of 10 or more. Reserve in advance!",
  },
  {
    icon: Percent,
    title: "Loyalty Rewards",
    description: "Earn points on every order. Redeem for free meals!",
  },
]

export default function OffersPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-primary shadow-md">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2 text-white">
              <ArrowLeft className="h-5 w-5" />
              <span className="font-medium">Back to Home</span>
            </Link>
            <h1 className="font-heading text-xl font-bold text-white">
              Special Offers
            </h1>
            <Link href="/menu">
              <Button variant="secondary" size="sm">
                View Menu
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Banner */}
      <section className="relative py-16 bg-gradient-to-br from-primary via-primary to-accent overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-32 h-32 border-4 border-white rounded-full" />
          <div className="absolute bottom-10 right-10 w-48 h-48 border-4 border-white rounded-full" />
          <div className="absolute top-1/2 left-1/3 w-24 h-24 border-4 border-white rounded-full" />
        </div>
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <Badge className="bg-secondary text-secondary-foreground mb-4">
            <Tag className="h-3 w-3 mr-1" />
            Limited Time Offers
          </Badge>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4 text-balance">
            Delicious Deals Await You!
          </h2>
          <p className="text-white/80 max-w-2xl mx-auto text-lg">
            Save big on your favorite meals with our exclusive offers and combo deals. 
            Quality food at pocket-friendly prices!
          </p>
        </div>
      </section>

      {/* Quick Deals */}
      <section className="py-10 bg-muted">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-6">
            {quickDeals.map((deal, index) => (
              <div 
                key={index}
                className="flex items-start gap-4 bg-card p-5 rounded-xl shadow-sm"
              >
                <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center shrink-0">
                  <deal.icon className="h-6 w-6 text-secondary" />
                </div>
                <div>
                  <h3 className="font-heading font-semibold text-primary mb-1">
                    {deal.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {deal.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Offers Grid */}
      <section className="py-12 lg:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h3 className="font-heading text-2xl sm:text-3xl font-bold text-primary mb-3">
              Combo Offers & Deals
            </h3>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Grab these amazing offers before they expire!
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {offers.map((offer) => (
              <Card 
                key={offer.id} 
                className="overflow-hidden group hover:shadow-lg transition-all duration-300"
              >
                <div className="relative h-48">
                  <Image
                    src={offer.image}
                    alt={offer.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-3 left-3">
                    <Badge className="bg-accent text-accent-foreground">
                      {offer.tag}
                    </Badge>
                  </div>
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-secondary text-secondary-foreground font-bold">
                      {offer.discount}
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-5">
                  <h4 className="font-heading font-bold text-lg text-primary mb-2">
                    {offer.title}
                  </h4>
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                    {offer.description}
                  </p>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-bold text-secondary">
                        Rs {offer.offerPrice}
                      </span>
                      <span className="text-sm text-muted-foreground line-through">
                        Rs {offer.originalPrice}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
                    <Clock className="h-3 w-3" />
                    <span>{offer.validTill}</span>
                  </div>
                  <Link href="/reserve">
                    <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                      Book This Offer
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Terms */}
      <section className="py-10 bg-muted">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="bg-card rounded-xl p-6 shadow-sm">
            <h4 className="font-heading font-semibold text-primary mb-3">
              Terms & Conditions
            </h4>
            <ul className="text-sm text-muted-foreground space-y-2">
              <li>- Offers cannot be combined with other promotions or discounts</li>
              <li>- Management reserves the right to modify or withdraw offers without prior notice</li>
              <li>- Valid for dine-in only unless otherwise specified</li>
              <li>- Student offers require valid student ID verification</li>
              <li>- Birthday offers valid only on the exact birthday date with valid ID proof</li>
            </ul>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 bg-primary">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="font-heading text-2xl font-bold text-white mb-4">
            Ready to Order?
          </h3>
          <p className="text-white/80 mb-6 max-w-xl mx-auto">
            Visit us today or call to place your order. We&apos;re here to serve you!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/order">
              <Button size="lg" variant="secondary">
                Order Online
              </Button>
            </Link>
            <Link href="tel:+919281433449">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                Call: +91 92814 33449
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
