"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Plus, Minus, ShoppingCart, Trash2, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { menuData } from "@/lib/menu-data"

interface CartItem {
  id: string
  name: string
  price: number
  quantity: number
  isVeg: boolean
}

export default function OrderPage() {
  const [cart, setCart] = useState<CartItem[]>([])
  const [activeSection, setActiveSection] = useState(menuData[0].id)
  const [showCart, setShowCart] = useState(false)
  const [orderType, setOrderType] = useState<"pickup" | "delivery">("pickup")
  const [customerInfo, setCustomerInfo] = useState({
    name: "",
    phone: "",
    address: "",
    notes: "",
  })
  
  const deliveryCharge = orderType === "delivery" ? 40 : 0
  const packingCharge = 20

  const addToCart = (item: { name: string; price: number; isVeg: boolean }) => {
    const id = item.name.toLowerCase().replace(/\s+/g, "-")
    setCart((prev) => {
      const existing = prev.find((i) => i.id === id)
      if (existing) {
        return prev.map((i) =>
          i.id === id ? { ...i, quantity: i.quantity + 1 } : i
        )
      }
      return [...prev, { id, name: item.name, price: item.price, quantity: 1, isVeg: item.isVeg }]
    })
  }

  const removeFromCart = (id: string) => {
    setCart((prev) => prev.filter((i) => i.id !== id))
  }

  const updateQuantity = (id: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((i) => (i.id === id ? { ...i, quantity: i.quantity + delta } : i))
        .filter((i) => i.quantity > 0)
    )
  }

  const totalAmount = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0)

  const handleWhatsAppOrder = () => {
    if (!customerInfo.name || !customerInfo.phone) {
      alert("Please fill in your name and phone number")
      return
    }
    
    if (orderType === "delivery" && !customerInfo.address) {
      alert("Please fill in your delivery address")
      return
    }
    
    const orderItems = cart
      .map((item) => `${item.quantity}x ${item.name} - Rs ${item.price * item.quantity}`)
      .join("\n")
    
    const finalTotal = totalAmount + packingCharge + deliveryCharge
    
    const message = `*New ${orderType === "delivery" ? "Delivery" : "Pickup"} Order from VRR Hotel Website*\n\n*Customer Details:*\nName: ${customerInfo.name}\nPhone: ${customerInfo.phone}${orderType === "delivery" ? `\nDelivery Address: ${customerInfo.address}` : "\nOrder Type: Pickup from restaurant"}\n\n*Order Items:*\n${orderItems}\n\n*Subtotal:* Rs ${totalAmount}\n*Packing Charges:* Rs ${packingCharge}${orderType === "delivery" ? `\n*Delivery Charges:* Rs ${deliveryCharge}` : ""}\n*Total: Rs ${finalTotal}*\n\n*Special Instructions:* ${customerInfo.notes || "None"}`
    
    const whatsappUrl = `https://wa.me/919281433449?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-primary shadow-md">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2 text-white">
              <ArrowLeft className="h-5 w-5" />
              <span className="font-medium">Back</span>
            </Link>
            <h1 className="font-heading text-xl font-bold text-white">
              Order Online
            </h1>
            <Button 
              variant="secondary" 
              size="sm"
              onClick={() => setShowCart(true)}
              className="relative"
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              Cart
              {totalItems > 0 && (
                <Badge className="absolute -top-2 -right-2 bg-accent text-accent-foreground h-5 w-5 p-0 flex items-center justify-center text-xs">
                  {totalItems}
                </Badge>
              )}
            </Button>
          </div>
        </div>
      </header>

      {/* Section Tabs */}
      <div className="sticky top-16 z-40 bg-card border-b border-border shadow-sm">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex gap-2 overflow-x-auto py-3 scrollbar-hide">
            {menuData.map((section) => (
              <button
                key={section.id}
                onClick={() => setActiveSection(section.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                  activeSection === section.id
                    ? "bg-secondary text-secondary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                {section.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <main className="py-6">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {menuData
            .filter((section) => section.id === activeSection)
            .map((section) => (
              <div key={section.id}>
                {section.categories.map((category) => (
                  <div key={category.id} className="mb-8">
                    <h3 className="font-heading text-lg font-semibold text-primary mb-4 flex items-center gap-2">
                      <span className={`w-3 h-3 rounded-full ${
                        category.name.toLowerCase().includes("non-veg") || 
                        category.name.toLowerCase().includes("non veg") ||
                        category.name.toLowerCase().includes("sea food") ||
                        category.name.toLowerCase().includes("seafood")
                          ? "bg-red-600" 
                          : "bg-green-600"
                      }`} />
                      {category.name}
                    </h3>
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      {category.items.map((item, index) => {
                        const cartItem = cart.find(
                          (i) => i.id === item.name.toLowerCase().replace(/\s+/g, "-")
                        )
                        return (
                          <Card key={index} className="overflow-hidden">
                            <CardContent className="p-4">
                              <div className="flex items-start justify-between gap-3">
                                <div className="flex items-start gap-3 flex-1">
                                  <span className={`mt-1 inline-flex items-center justify-center w-4 h-4 border-2 rounded flex-shrink-0 ${
                                    item.isVeg ? "border-green-600" : "border-red-600"
                                  }`}>
                                    <span className={`w-2 h-2 rounded-full ${
                                      item.isVeg ? "bg-green-600" : "bg-red-600"
                                    }`} />
                                  </span>
                                  <div>
                                    <h4 className="font-medium text-foreground text-sm">
                                      {item.name}
                                    </h4>
                                    <p className="text-secondary font-semibold text-sm mt-1">
                                      Rs {item.price}
                                    </p>
                                  </div>
                                </div>
                                {cartItem ? (
                                  <div className="flex items-center gap-2 bg-secondary/10 rounded-lg p-1">
                                    <button
                                      onClick={() => updateQuantity(cartItem.id, -1)}
                                      className="w-7 h-7 flex items-center justify-center rounded bg-secondary text-secondary-foreground"
                                    >
                                      <Minus className="h-3 w-3" />
                                    </button>
                                    <span className="w-6 text-center font-medium text-sm">
                                      {cartItem.quantity}
                                    </span>
                                    <button
                                      onClick={() => updateQuantity(cartItem.id, 1)}
                                      className="w-7 h-7 flex items-center justify-center rounded bg-secondary text-secondary-foreground"
                                    >
                                      <Plus className="h-3 w-3" />
                                    </button>
                                  </div>
                                ) : (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => addToCart(item)}
                                    className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground"
                                  >
                                    <Plus className="h-4 w-4" />
                                  </Button>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                        )
                      })}
                    </div>
                  </div>
                ))}
              </div>
            ))}
        </div>
      </main>

      {/* Fixed Cart Summary */}
      {totalItems > 0 && !showCart && (
        <div className="fixed bottom-0 left-0 right-0 bg-primary p-4 shadow-lg z-40">
          <div className="mx-auto max-w-7xl flex items-center justify-between">
            <div className="text-white">
              <span className="font-medium">{totalItems} items</span>
              <span className="mx-2">|</span>
              <span className="font-bold">Rs {totalAmount}</span>
            </div>
            <Button 
              variant="secondary" 
              onClick={() => setShowCart(true)}
            >
              View Cart
            </Button>
          </div>
        </div>
      )}

      {/* Cart Sidebar */}
      {showCart && (
        <div className="fixed inset-0 z-50 bg-black/50" onClick={() => setShowCart(false)}>
          <div 
            className="absolute right-0 top-0 h-full w-full max-w-md bg-background shadow-xl overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 bg-primary p-4 flex items-center justify-between">
              <h2 className="font-heading text-xl font-bold text-white">Your Cart</h2>
              <button 
                onClick={() => setShowCart(false)}
                className="text-white hover:text-white/80"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            {cart.length === 0 ? (
              <div className="p-8 text-center">
                <ShoppingCart className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Your cart is empty</p>
                <Button 
                  className="mt-4" 
                  variant="outline"
                  onClick={() => setShowCart(false)}
                >
                  Browse Menu
                </Button>
              </div>
            ) : (
              <div className="p-4">
                {/* Cart Items */}
                <div className="space-y-3 mb-6">
                  {cart.map((item) => (
                    <div 
                      key={item.id}
                      className="flex items-center gap-3 bg-card p-3 rounded-lg border border-border"
                    >
                      <span className={`inline-flex items-center justify-center w-4 h-4 border-2 rounded flex-shrink-0 ${
                        item.isVeg ? "border-green-600" : "border-red-600"
                      }`}>
                        <span className={`w-2 h-2 rounded-full ${
                          item.isVeg ? "bg-green-600" : "bg-red-600"
                        }`} />
                      </span>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm text-foreground truncate">
                          {item.name}
                        </h4>
                        <p className="text-secondary text-sm font-semibold">
                          Rs {item.price * item.quantity}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateQuantity(item.id, -1)}
                          className="w-7 h-7 flex items-center justify-center rounded bg-muted text-foreground"
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="w-6 text-center font-medium text-sm">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.id, 1)}
                          className="w-7 h-7 flex items-center justify-center rounded bg-muted text-foreground"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-destructive hover:text-destructive/80"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Order Type Selection */}
                <div className="mb-6">
                  <h3 className="font-heading font-semibold text-primary mb-3">
                    Order Type
                  </h3>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => setOrderType("pickup")}
                      className={`p-4 rounded-lg border-2 text-center transition-all ${
                        orderType === "pickup"
                          ? "border-secondary bg-secondary/10"
                          : "border-border hover:border-secondary/50"
                      }`}
                    >
                      <div className="font-semibold text-foreground">Pickup</div>
                      <div className="text-xs text-muted-foreground mt-1">
                        Collect from restaurant
                      </div>
                      <div className="text-xs text-green-600 font-medium mt-1">
                        Free
                      </div>
                    </button>
                    <button
                      onClick={() => setOrderType("delivery")}
                      className={`p-4 rounded-lg border-2 text-center transition-all ${
                        orderType === "delivery"
                          ? "border-secondary bg-secondary/10"
                          : "border-border hover:border-secondary/50"
                      }`}
                    >
                      <div className="font-semibold text-foreground">Delivery</div>
                      <div className="text-xs text-muted-foreground mt-1">
                        To your doorstep
                      </div>
                      <div className="text-xs text-secondary font-medium mt-1">
                        Rs 40
                      </div>
                    </button>
                  </div>
                </div>

                {/* Customer Info */}
                <div className="space-y-4 mb-6">
                  <h3 className="font-heading font-semibold text-primary">
                    Your Details
                  </h3>
                  <Input
                    placeholder="Your Name *"
                    value={customerInfo.name}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, name: e.target.value })}
                  />
                  <Input
                    placeholder="Phone Number *"
                    type="tel"
                    value={customerInfo.phone}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, phone: e.target.value })}
                  />
                  {orderType === "delivery" && (
                    <Textarea
                      placeholder="Delivery Address *"
                      value={customerInfo.address}
                      onChange={(e) => setCustomerInfo({ ...customerInfo, address: e.target.value })}
                      rows={2}
                    />
                  )}
                  <Textarea
                    placeholder="Special instructions (optional)"
                    value={customerInfo.notes}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, notes: e.target.value })}
                    rows={2}
                  />
                </div>

                {/* Order Summary */}
                <div className="bg-muted rounded-lg p-4 mb-6">
                  <div className="flex justify-between mb-2">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span className="font-medium">Rs {totalAmount}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-muted-foreground">Packing Charges</span>
                    <span className="font-medium">Rs {packingCharge}</span>
                  </div>
                  {orderType === "delivery" && (
                    <div className="flex justify-between mb-2">
                      <span className="text-muted-foreground">Delivery Charges</span>
                      <span className="font-medium">Rs {deliveryCharge}</span>
                    </div>
                  )}
                  <div className="border-t border-border pt-2 mt-2 flex justify-between">
                    <span className="font-semibold text-primary">Total</span>
                    <span className="font-bold text-secondary text-lg">
                      Rs {totalAmount + packingCharge + deliveryCharge}
                    </span>
                  </div>
                </div>

                {/* Order Button */}
                <Button 
                  className="w-full bg-green-600 hover:bg-green-700 text-white h-12"
                  onClick={handleWhatsAppOrder}
                >
                  <Image
                    src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg"
                    alt="WhatsApp"
                    width={20}
                    height={20}
                    className="mr-2"
                  />
                  Order via WhatsApp
                </Button>
                <p className="text-xs text-center text-muted-foreground mt-3">
                  Your order will be sent to our WhatsApp for confirmation
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
