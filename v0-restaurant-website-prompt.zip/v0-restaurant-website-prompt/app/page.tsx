import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { AboutSection } from "@/components/about-section"
import { MenuSection } from "@/components/menu-section"
import { OffersSection } from "@/components/offers-section"
import { WhyUsSection } from "@/components/why-us-section"
import { ReviewsSection } from "@/components/reviews-section"
import { GallerySection } from "@/components/gallery-section"
import { ContactSection } from "@/components/contact-section"
import { CTASection } from "@/components/cta-section"
import { Footer } from "@/components/footer"
import { WhatsAppButton } from "@/components/whatsapp-button"

export default function Home() {
  return (
    <main>
      <Navbar />
      <HeroSection />
      <AboutSection />
      <MenuSection />
      <OffersSection />
      <WhyUsSection />
      <ReviewsSection />
      <GallerySection />
      <ContactSection />
      <CTASection />
      <Footer />
      <WhatsAppButton />
    </main>
  )
}
