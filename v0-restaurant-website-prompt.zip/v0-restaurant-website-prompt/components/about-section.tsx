import Image from "next/image"
import { Award, Users, Heart } from "lucide-react"

export function AboutSection() {
  return (
    <section id="about" className="py-20 lg:py-28 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image Side */}
          <div className="relative">
            <div className="relative aspect-[4/5] rounded-2xl overflow-hidden">
              <Image
                src="/images/restaurant-interior.jpg"
                alt="VRR Hotel comfortable interior"
                fill
                className="object-cover"
              />
            </div>
            {/* Floating Card */}
            <div className="absolute -bottom-6 -right-6 bg-white rounded-xl shadow-xl p-6 max-w-[200px]">
              <div className="text-4xl font-heading font-bold text-secondary">10+</div>
              <p className="text-muted-foreground text-sm mt-1">Years of serving delicious food</p>
            </div>
          </div>

          {/* Content Side */}
          <div>
            <span className="text-secondary font-medium text-sm uppercase tracking-wider">
              Our Story
            </span>
            <h2 className="font-heading text-3xl sm:text-4xl font-bold text-primary mt-3 mb-6 text-balance">
              Where Every Meal Feels Like Home
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-6">
              VRR Hotel has been a beloved dining destination in Nellore for years. 
              We take pride in serving authentic South Indian cuisine that brings families, 
              students, and food lovers together. Our commitment to quality ingredients, 
              hygienic preparation, and affordable pricing has made us a local favorite.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              From our famous morning tiffins to hearty meals and delicious non-veg specials, 
              every dish is prepared with care and served with warmth. Step into VRR Hotel 
              and experience the perfect blend of taste, comfort, and value.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6">
              <div className="text-center p-4 bg-muted rounded-xl">
                <Award className="h-8 w-8 text-secondary mx-auto mb-2" />
                <div className="font-heading font-bold text-xl text-primary">4.6</div>
                <p className="text-muted-foreground text-xs mt-1">Rating</p>
              </div>
              <div className="text-center p-4 bg-muted rounded-xl">
                <Users className="h-8 w-8 text-secondary mx-auto mb-2" />
                <div className="font-heading font-bold text-xl text-primary">10K+</div>
                <p className="text-muted-foreground text-xs mt-1">Happy Customers</p>
              </div>
              <div className="text-center p-4 bg-muted rounded-xl">
                <Heart className="h-8 w-8 text-secondary mx-auto mb-2" />
                <div className="font-heading font-bold text-xl text-primary">50+</div>
                <p className="text-muted-foreground text-xs mt-1">Menu Items</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
