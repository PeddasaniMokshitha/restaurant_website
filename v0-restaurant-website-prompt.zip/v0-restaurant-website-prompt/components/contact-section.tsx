import { MapPin, Phone, Clock, Navigation } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function ContactSection() {
  return (
    <section id="contact" className="py-20 lg:py-28 bg-muted">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-14">
          <span className="text-secondary font-medium text-sm uppercase tracking-wider">
            Find Us
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-primary mt-3 mb-4 text-balance">
            Visit VRR Hotel Today
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            We&apos;re conveniently located in Nellore and always ready to serve you 
            delicious food with a smile.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-10">
          {/* Contact Info */}
          <div className="space-y-8">
            {/* Address Card */}
            <div className="bg-card rounded-2xl p-6 shadow-md">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center shrink-0">
                  <MapPin className="h-6 w-6 text-secondary" />
                </div>
                <div>
                  <h3 className="font-heading font-semibold text-lg text-primary mb-2">
                    Our Location
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Shop 4, Police Colony, Opp. Bharat Petrol Bunk,<br />
                    Telugu Ganga Colony, Vengalrao Nagar,<br />
                    Nellore, Andhra Pradesh 524004
                  </p>
                </div>
              </div>
            </div>

            {/* Phone Card */}
            <div className="bg-card rounded-2xl p-6 shadow-md">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center shrink-0">
                  <Phone className="h-6 w-6 text-secondary" />
                </div>
                <div>
                  <h3 className="font-heading font-semibold text-lg text-primary mb-2">
                    Phone Number
                  </h3>
                  <p className="text-muted-foreground">
                    <Link 
                      href="tel:+919281433449" 
                      className="hover:text-secondary transition-colors"
                    >
                      +91 92814 33449
                    </Link>
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Call us for orders and reservations
                  </p>
                </div>
              </div>
            </div>

            {/* Hours Card */}
            <div className="bg-card rounded-2xl p-6 shadow-md">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center shrink-0">
                  <Clock className="h-6 w-6 text-secondary" />
                </div>
                <div>
                  <h3 className="font-heading font-semibold text-lg text-primary mb-2">
                    Opening Hours
                  </h3>
                  <div className="text-muted-foreground">
                    <p className="flex justify-between">
                      <span>Monday - Sunday</span>
                      <span className="font-medium text-foreground">6:00 AM - 10:30 PM</span>
                    </p>
                    <p className="text-sm mt-2 text-secondary font-medium">
                      Open Daily
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Link 
                href="https://maps.google.com/?q=VRR+Hotel+Nellore" 
                target="_blank"
                className="flex-1"
              >
                <Button 
                  size="lg" 
                  className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90 gap-2"
                >
                  <Navigation className="h-5 w-5" />
                  Get Directions
                </Button>
              </Link>
              <Link href="tel:+919281433449" className="flex-1">
                <Button 
                  size="lg" 
                  variant="outline"
                  className="w-full border-primary text-primary hover:bg-primary hover:text-primary-foreground gap-2"
                >
                  <Phone className="h-5 w-5" />
                  Call Now
                </Button>
              </Link>
            </div>
          </div>

          {/* Map Placeholder */}
          <div className="relative bg-card rounded-2xl overflow-hidden shadow-md min-h-[400px]">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3862.8462073!2d79.9865!3d14.4478!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTTCsDI2JzUyLjEiTiA3OcKwNTknMTEuNCJF!5e0!3m2!1sen!2sin!4v1234567890"
              width="100%"
              height="100%"
              style={{ border: 0, minHeight: "400px" }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="VRR Hotel Location"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
