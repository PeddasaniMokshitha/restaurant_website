import Link from "next/link"
import { Button } from "@/components/ui/button"

export function CTASection() {
  return (
    <section className="py-20 lg:py-28 bg-primary relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-0 w-96 h-96 bg-secondary rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-secondary rounded-full blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 text-balance">
          Visit VRR Hotel Today
        </h2>
        <p className="text-white/80 text-lg max-w-2xl mx-auto mb-10 text-pretty">
          Taste delicious food in a welcoming atmosphere without spending too much. 
          Your next favorite meal is waiting for you.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/reserve">
            <Button 
              size="lg" 
              className="bg-secondary text-secondary-foreground hover:bg-secondary/90 text-base px-8 h-12 w-full sm:w-auto"
            >
              Reserve a Table
            </Button>
          </Link>
          <Link href="/menu">
            <Button 
              size="lg" 
              variant="outline"
              className="border-2 border-white text-white hover:bg-white hover:text-primary text-base px-8 h-12 w-full sm:w-auto"
            >
              View Menu
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
