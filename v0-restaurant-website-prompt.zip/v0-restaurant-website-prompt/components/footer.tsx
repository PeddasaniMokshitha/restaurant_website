import Link from "next/link"
import { Phone, MapPin, Clock, Instagram, Facebook } from "lucide-react"

const quickLinks = [
  { href: "#home", label: "Home" },
  { href: "#about", label: "About Us" },
  { href: "#menu", label: "Menu" },
  { href: "#reviews", label: "Reviews" },
  { href: "#gallery", label: "Gallery" },
  { href: "#contact", label: "Contact" },
]

export function Footer() {
  return (
    <footer className="bg-primary text-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Link href="#home" className="inline-block mb-4">
              <span className="font-heading text-2xl font-bold text-white">
                VRR Hotel
              </span>
            </Link>
            <p className="text-white/70 text-sm leading-relaxed mb-6">
              Affordable Taste. Memorable Experience. Serving delicious South Indian 
              cuisine in a warm and welcoming atmosphere.
            </p>
            <div className="flex items-center gap-4">
              <Link 
                href="#" 
                className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-secondary transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="h-5 w-5" />
              </Link>
              <Link 
                href="#" 
                className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-secondary transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </Link>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-heading font-semibold text-lg mb-5">
              Quick Links
            </h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <Link 
                    href={link.href}
                    className="text-white/70 hover:text-secondary transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-heading font-semibold text-lg mb-5">
              Contact Us
            </h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-secondary shrink-0 mt-0.5" />
                <span className="text-white/70 text-sm">
                  Shop 4, Police Colony, Nellore,<br />
                  Andhra Pradesh 524004
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-secondary shrink-0" />
                <Link 
                  href="tel:+919281433449"
                  className="text-white/70 hover:text-secondary transition-colors text-sm"
                >
                  +91 92814 33449
                </Link>
              </li>
            </ul>
          </div>

          {/* Opening Hours */}
          <div>
            <h4 className="font-heading font-semibold text-lg mb-5">
              Opening Hours
            </h4>
            <div className="flex items-start gap-3">
              <Clock className="h-5 w-5 text-secondary shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="text-white/70">Monday - Sunday</p>
                <p className="text-white font-medium">6:00 AM - 10:30 PM</p>
                <p className="text-secondary text-xs mt-2 font-medium">
                  Open Daily
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
          <p className="text-center text-white/50 text-sm">
            © {new Date().getFullYear()} VRR Hotel. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}
