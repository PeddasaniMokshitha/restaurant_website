"use client"

import Image from "next/image"
import { useState } from "react"
import { X } from "lucide-react"

const galleryImages = [
  { src: "/images/hero-food.jpg", alt: "South Indian food spread" },
  { src: "/images/restaurant-interior.jpg", alt: "Restaurant interior" },
  { src: "/images/dosa.jpg", alt: "Crispy Masala Dosa" },
  { src: "/images/idli.jpg", alt: "Fresh Idli with Chutney" },
  { src: "/images/fried-rice.jpg", alt: "Chicken Fried Rice" },
  { src: "/images/family-dining.jpg", alt: "Family dining experience" },
  { src: "/images/noodles.jpg", alt: "Hakka Noodles" },
  { src: "/images/veg-meal.jpg", alt: "Vegetarian Thali" },
]

export function GallerySection() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null)

  return (
    <section id="gallery" className="py-20 lg:py-28 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-14">
          <span className="text-secondary font-medium text-sm uppercase tracking-wider">
            Gallery
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-primary mt-3 mb-4 text-balance">
            A Glimpse of VRR Hotel
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Take a visual tour of our restaurant, the delicious food we serve, 
            and the warm ambience that awaits you.
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {galleryImages.map((image, index) => (
            <button
              key={index}
              onClick={() => setSelectedImage(image.src)}
              className={`relative overflow-hidden rounded-xl group cursor-pointer ${
                index === 0 ? "md:col-span-2 md:row-span-2" : ""
              }`}
            >
              <div className={`relative ${index === 0 ? "aspect-square" : "aspect-square"}`}>
                <Image
                  src={image.src}
                  alt={image.alt}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors duration-300 flex items-center justify-center">
                  <span className="text-white font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                    View
                  </span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {selectedImage && (
        <div 
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <button 
            className="absolute top-4 right-4 text-white p-2 hover:bg-white/10 rounded-full transition-colors"
            onClick={() => setSelectedImage(null)}
            aria-label="Close lightbox"
          >
            <X className="h-8 w-8" />
          </button>
          <div className="relative max-w-4xl w-full aspect-video">
            <Image
              src={selectedImage}
              alt="Gallery image"
              fill
              className="object-contain"
            />
          </div>
        </div>
      )}
    </section>
  )
}
