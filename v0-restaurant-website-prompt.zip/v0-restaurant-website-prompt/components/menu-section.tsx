import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

const menuItems = [
  {
    name: "South Indian Tiffins",
    description: "Fluffy idli, crispy dosa, medu vada with sambar & chutney",
    price: "₹40",
    image: "/images/idli.jpg",
    popular: true,
  },
  {
    name: "Masala Dosa",
    description: "Crispy golden dosa filled with spiced potato masala",
    price: "₹60",
    image: "/images/dosa.jpg",
    popular: true,
  },
  {
    name: "Veg Meals",
    description: "Complete South Indian thali with rice, dal, sambar & more",
    price: "₹80",
    image: "/images/veg-meal.jpg",
    popular: false,
  },
  {
    name: "Chicken Fried Rice",
    description: "Aromatic rice with tender chicken pieces & vegetables",
    price: "₹120",
    image: "/images/fried-rice.jpg",
    popular: true,
  },
  {
    name: "Hakka Noodles",
    description: "Indo-Chinese style noodles with fresh vegetables",
    price: "₹100",
    image: "/images/noodles.jpg",
    popular: false,
  },
  {
    name: "Fast Food Specials",
    description: "Samosa, pav bhaji, and other quick bites",
    price: "₹50",
    image: "/images/fast-food.jpg",
    popular: false,
  },
]

export function MenuSection() {
  return (
    <section id="menu" className="py-20 lg:py-28 bg-muted">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-14">
          <span className="text-secondary font-medium text-sm uppercase tracking-wider">
            Our Menu
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-primary mt-3 mb-4 text-balance">
            Explore Our Delicious Offerings
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            From traditional South Indian tiffins to flavorful rice dishes and fast food, 
            we have something for everyone at prices that won&apos;t break the bank.
          </p>
        </div>

        {/* Menu Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {menuItems.map((item) => (
            <Card key={item.name} className="group overflow-hidden bg-card border-0 shadow-md hover:shadow-xl transition-shadow duration-300">
              <div className="relative aspect-[4/3] overflow-hidden">
                <Image
                  src={item.image}
                  alt={item.name}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                {item.popular && (
                  <div className="absolute top-4 left-4 bg-secondary text-secondary-foreground text-xs font-semibold px-3 py-1 rounded-full">
                    Popular
                  </div>
                )}
              </div>
              <CardContent className="p-5">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-heading font-semibold text-lg text-primary">
                    {item.name}
                  </h3>
                  <span className="text-secondary font-bold text-lg">
                    {item.price}
                  </span>
                </div>
                <p className="text-muted-foreground text-sm mb-4">
                  {item.description}
                </p>
                                <Link href="/menu">
                  <Button 
                    size="sm" 
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    View Details
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* View Full Menu CTA */}
        <div className="text-center mt-12">
          <p className="text-muted-foreground mb-4">
            Want to see our complete menu?
          </p>
          <Link href="/menu">
            <Button 
              size="lg" 
              variant="outline"
              className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground"
            >
              View Full Menu
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
