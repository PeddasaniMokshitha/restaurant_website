import Image from "next/image"
import Link from "next/link"
import { Tag, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const featuredOffers = [
  {
    title: "Family Feast Combo",
    description: "4 Meals + 4 Drinks + 2 Desserts",
    originalPrice: 1200,
    offerPrice: 899,
    discount: "25% OFF",
    image: "/images/family-dining.jpg",
  },
  {
    title: "Breakfast Special",
    description: "2 Idli + 2 Vada + 1 Dosa + Coffee",
    originalPrice: 180,
    offerPrice: 129,
    discount: "28% OFF",
    image: "/images/idli.jpg",
  },
  {
    title: "Biryani Bonanza",
    description: "2 Biryanis + Raita + 2 Drinks FREE",
    originalPrice: 500,
    offerPrice: 399,
    discount: "20% OFF",
    image: "/images/fried-rice.jpg",
  },
]

export function OffersSection() {
  return (
    <section id="offers" className="py-20 lg:py-28 bg-muted">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-14">
          <span className="inline-flex items-center gap-2 text-secondary font-medium text-sm uppercase tracking-wider">
            <Tag className="h-4 w-4" />
            Special Offers
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-primary mt-3 mb-4 text-balance">
            Today&apos;s Best Deals
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Save big on your favorite meals with our exclusive combo offers and discounts.
          </p>
        </div>

        {/* Offers Grid */}
        <div className="grid md:grid-cols-3 gap-6 mb-10">
          {featuredOffers.map((offer, index) => (
            <Card key={index} className="overflow-hidden group hover:shadow-lg transition-all duration-300">
              <div className="relative h-48">
                <Image
                  src={offer.image}
                  alt={offer.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 right-3">
                  <Badge className="bg-secondary text-secondary-foreground font-bold">
                    {offer.discount}
                  </Badge>
                </div>
              </div>
              <CardContent className="p-5">
                <h4 className="font-heading font-bold text-lg text-primary mb-1">
                  {offer.title}
                </h4>
                <p className="text-sm text-muted-foreground mb-3">
                  {offer.description}
                </p>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold text-secondary">
                    Rs {offer.offerPrice}
                  </span>
                  <span className="text-sm text-muted-foreground line-through">
                    Rs {offer.originalPrice}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <Link href="/offers">
            <Button 
              size="lg" 
              className="bg-secondary text-secondary-foreground hover:bg-secondary/90 gap-2"
            >
              View All Offers
              <ArrowRight className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
