import { Star, Quote } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const reviews = [
  {
    name: "Rajesh Kumar",
    rating: 5,
    text: "Best place within budget! The food quality is amazing and the prices are very reasonable. My family loves coming here.",
    avatar: "RK",
  },
  {
    name: "Priya Sharma",
    rating: 5,
    text: "Great ambience and tasty food. The dosas here are crispy and delicious. Perfect for breakfast with family.",
    avatar: "PS",
  },
  {
    name: "Venkat Rao",
    rating: 4,
    text: "Morning tiffins are very good! I come here regularly for idli and dosa. Fresh and hygienic food every time.",
    avatar: "VR",
  },
  {
    name: "Lakshmi Devi",
    rating: 5,
    text: "Good dine-in experience. The staff is friendly and the restaurant is very clean. Highly recommend for families.",
    avatar: "LD",
  },
]

export function ReviewsSection() {
  return (
    <section id="reviews" className="py-20 lg:py-28 bg-muted">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-14">
          <span className="text-secondary font-medium text-sm uppercase tracking-wider">
            Testimonials
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-primary mt-3 mb-4 text-balance">
            What Our Customers Say
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Don&apos;t just take our word for it. Here&apos;s what our happy customers 
            have to say about their dining experience at VRR Hotel.
          </p>
        </div>

        {/* Reviews Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {reviews.map((review) => (
            <Card key={review.name} className="bg-card border-0 shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <Quote className="h-8 w-8 text-secondary/30 mb-4" />
                <p className="text-foreground text-sm leading-relaxed mb-6">
                  &ldquo;{review.text}&rdquo;
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-secondary/10 rounded-full flex items-center justify-center">
                    <span className="text-secondary font-semibold text-sm">
                      {review.avatar}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-primary text-sm">{review.name}</p>
                    <div className="flex items-center gap-1 mt-1">
                      {Array.from({ length: review.rating }).map((_, i) => (
                        <Star key={i} className="h-3 w-3 text-secondary fill-secondary" />
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Rating Summary */}
        <div className="mt-14 text-center">
          <div className="inline-flex items-center gap-4 bg-card rounded-2xl px-8 py-5 shadow-md">
            <div className="flex items-center gap-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star 
                  key={i} 
                  className={`h-6 w-6 ${i < 4 ? "text-secondary fill-secondary" : "text-secondary fill-secondary/50"}`} 
                />
              ))}
            </div>
            <div className="text-left">
              <p className="font-heading font-bold text-2xl text-primary">4.6/5</p>
              <p className="text-muted-foreground text-sm">Based on customer reviews</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
