import { 
  Banknote, 
  ShieldCheck, 
  Timer, 
  Users, 
  Leaf, 
  Utensils 
} from "lucide-react"

const features = [
  {
    icon: Banknote,
    title: "Affordable Pricing",
    description: "Quality food at budget-friendly prices that everyone can enjoy",
  },
  {
    icon: ShieldCheck,
    title: "Hygienic Kitchen",
    description: "Clean and sanitized kitchen ensuring safe and healthy meals",
  },
  {
    icon: Timer,
    title: "Fast Service",
    description: "Quick preparation and serving so you never have to wait long",
  },
  {
    icon: Users,
    title: "Family-Friendly",
    description: "Comfortable ambience perfect for family gatherings and celebrations",
  },
  {
    icon: Leaf,
    title: "Fresh Ingredients",
    description: "We use only fresh, quality ingredients in all our preparations",
  },
  {
    icon: Utensils,
    title: "Veg & Non-Veg",
    description: "Wide variety of both vegetarian and non-vegetarian options",
  },
]

export function WhyUsSection() {
  return (
    <section id="why-us" className="py-20 lg:py-28 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-14">
          <span className="text-secondary font-medium text-sm uppercase tracking-wider">
            Why Choose Us
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-primary mt-3 mb-4 text-balance">
            What Makes VRR Hotel Special
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            We&apos;re committed to providing an exceptional dining experience with 
            delicious food, great service, and a welcoming atmosphere.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature) => (
            <div 
              key={feature.title}
              className="group p-6 bg-card rounded-2xl border border-border hover:border-secondary/30 hover:shadow-lg transition-all duration-300"
            >
              <div className="w-14 h-14 bg-secondary/10 rounded-xl flex items-center justify-center mb-5 group-hover:bg-secondary/20 transition-colors">
                <feature.icon className="h-7 w-7 text-secondary" />
              </div>
              <h3 className="font-heading font-semibold text-lg text-primary mb-2">
                {feature.title}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
