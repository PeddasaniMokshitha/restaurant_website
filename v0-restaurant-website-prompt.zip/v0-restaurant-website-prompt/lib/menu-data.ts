export interface MenuItem {
  name: string
  description?: string
  isVeg: boolean
  price: number
}

export interface MenuCategory {
  id: string
  name: string
  items: MenuItem[]
}

export interface MenuSection {
  id: string
  name: string
  categories: MenuCategory[]
}

export const menuData: MenuSection[] = [
  {
    id: "soups",
    name: "Soups",
    categories: [
      {
        id: "veg-soups",
        name: "Veg Soups",
        items: [
          { name: "Hot and Sour Soup", isVeg: true, price: 99 },
          { name: "Lemon Coriander Soup", isVeg: true, price: 89 },
          { name: "Sweet Corn Soup", isVeg: true, price: 99 },
          { name: "Manchow Soup", description: "Veg preparation", isVeg: true, price: 109 },
          { name: "Clear Soup", description: "Veg preparation", isVeg: true, price: 79 },
          { name: "Lemon Pepper Soup", isVeg: true, price: 89 },
          { name: "Cream of Tomato Soup", isVeg: true, price: 99 },
          { name: "Cream of Mushroom Soup", isVeg: true, price: 119 },
        ],
      },
      {
        id: "non-veg-soups",
        name: "Non Veg Soups",
        items: [
          { name: "Cream of Chicken Soup", isVeg: false, price: 139 },
          { name: "Chicken Hot and Sour Soup", isVeg: false, price: 129 },
          { name: "Chicken Lemon Coriander Soup", isVeg: false, price: 119 },
          { name: "Chicken Sweet Corn Soup", isVeg: false, price: 129 },
          { name: "Chicken Manchow Soup", isVeg: false, price: 139 },
          { name: "Chicken Clear Soup", isVeg: false, price: 109 },
          { name: "Chicken Lemon Pepper Soup", isVeg: false, price: 119 },
        ],
      },
    ],
  },
  {
    id: "starters",
    name: "Starters",
    categories: [
      {
        id: "veg-starters",
        name: "Veg Starters",
        items: [
          { name: "Gobi Manchurian", isVeg: true, price: 179 },
          { name: "Chilli Gobi", isVeg: true, price: 179 },
          { name: "Baby Corn Manchurian", isVeg: true, price: 189 },
          { name: "Chilli Baby Corn", isVeg: true, price: 189 },
          { name: "Mushroom Salt and Pepper", isVeg: true, price: 199 },
          { name: "Mushroom Manchurian", isVeg: true, price: 199 },
          { name: "Pepper Mushroom", isVeg: true, price: 199 },
          { name: "Crispy Corn", isVeg: true, price: 169 },
          { name: "Paneer Majestic", isVeg: true, price: 229 },
          { name: "Chilli Paneer", isVeg: true, price: 219 },
          { name: "Gobi 65", isVeg: true, price: 169 },
          { name: "Paneer 65", isVeg: true, price: 219 },
          { name: "Mushroom 65", isVeg: true, price: 189 },
          { name: "Chilli Mushroom", isVeg: true, price: 199 },
        ],
      },
      {
        id: "tandoori-veg-starters",
        name: "Tandoori Veg Starters",
        items: [
          { name: "Paneer Tikka", isVeg: true, price: 259 },
        ],
      },
      {
        id: "non-veg-starters",
        name: "Non Veg Starters",
        items: [
          { name: "Egg Chilli", isVeg: false, price: 149 },
          { name: "Cashew Nut Chicken Dry", isVeg: false, price: 289 },
          { name: "Chicken 65", isVeg: false, price: 229 },
          { name: "Chicken 555", isVeg: false, price: 249 },
          { name: "Chilli Chicken", isVeg: false, price: 239 },
          { name: "Chicken Majestic", isVeg: false, price: 259 },
          { name: "Chicken Manchurian", isVeg: false, price: 249 },
          { name: "Chicken Lollipop", isVeg: false, price: 269 },
          { name: "Chicken Drumstick", isVeg: false, price: 279 },
          { name: "Pepper Chicken", isVeg: false, price: 249 },
          { name: "Dragon Chicken", isVeg: false, price: 259 },
          { name: "Honey Chicken", isVeg: false, price: 269 },
          { name: "R R Chicken", isVeg: false, price: 259 },
          { name: "Lemon Chicken", isVeg: false, price: 249 },
          { name: "Pepper Fry Chicken", isVeg: false, price: 259 },
          { name: "Chicken Roast Boneless", isVeg: false, price: 289 },
          { name: "Chicken Roast", isVeg: false, price: 269 },
          { name: "Chicken Fry Boneless", isVeg: false, price: 279 },
          { name: "Chicken Fry", isVeg: false, price: 249 },
          { name: "Banjara Kabab", isVeg: false, price: 299 },
          { name: "Tandoori Prawns", isVeg: false, price: 399 },
        ],
      },
      {
        id: "tandoori-non-veg-starters",
        name: "Tandoori Non Veg Starters",
        items: [
          { name: "Tandoori Chicken", isVeg: false, price: 329 },
          { name: "Chicken Tikka", isVeg: false, price: 289 },
          { name: "Chicken Garlic Tikka", isVeg: false, price: 299 },
          { name: "Achari Chicken Tikka", isVeg: false, price: 299 },
          { name: "Reshmi Kabab", isVeg: false, price: 309 },
          { name: "Tangdi Kabab", isVeg: false, price: 319 },
          { name: "Fish Garlic Tikka", isVeg: false, price: 349 },
        ],
      },
      {
        id: "seafood-starters",
        name: "Sea Food Starters",
        items: [
          { name: "Apollo Fish", isVeg: false, price: 319 },
          { name: "Chilli Fish", isVeg: false, price: 299 },
          { name: "Garlic Fish", isVeg: false, price: 309 },
          { name: "Lemon Fish", isVeg: false, price: 299 },
          { name: "Fish Pepper", isVeg: false, price: 309 },
          { name: "Loose Prawns", isVeg: false, price: 379 },
          { name: "Chilli Prawns", isVeg: false, price: 389 },
          { name: "Prawns 65", isVeg: false, price: 379 },
          { name: "Garlic Prawns", isVeg: false, price: 399 },
          { name: "Prawns Fry", isVeg: false, price: 369 },
          { name: "Golden Fry Prawns", isVeg: false, price: 389 },
        ],
      },
    ],
  },
  {
    id: "main-course",
    name: "Main Course",
    categories: [
      {
        id: "veg-main-course",
        name: "Veg Main Course",
        items: [
          { name: "Kaju Curry", isVeg: true, price: 249 },
          { name: "Kaju Paneer", isVeg: true, price: 269 },
          { name: "Veg Kadai", isVeg: true, price: 189 },
          { name: "Mix Veg", isVeg: true, price: 179 },
          { name: "Tomato Masala", isVeg: true, price: 149 },
          { name: "Capsicum Fry", isVeg: true, price: 159 },
          { name: "Dal Tadka", isVeg: true, price: 159 },
          { name: "Dal Fry", isVeg: true, price: 149 },
          { name: "Malai Kofta", isVeg: true, price: 219 },
          { name: "Paneer Kofta", isVeg: true, price: 229 },
          { name: "Veg Kofta", isVeg: true, price: 199 },
          { name: "Methi Chaman", isVeg: true, price: 209 },
          { name: "Baby Corn Masala", isVeg: true, price: 199 },
          { name: "Baby Corn Do Pyaaza", isVeg: true, price: 209 },
          { name: "Baby Corn Malai Masala", isVeg: true, price: 219 },
          { name: "Baby Corn Kadai", isVeg: true, price: 209 },
          { name: "Mushroom Masala", isVeg: true, price: 209 },
          { name: "Corn Masala", isVeg: true, price: 189 },
          { name: "Gobi Masala", isVeg: true, price: 179 },
          { name: "Kadai Mushroom", isVeg: true, price: 219 },
          { name: "Capsicum Mushroom Curry", isVeg: true, price: 209 },
          { name: "Kadai Paneer", isVeg: true, price: 229 },
          { name: "Paneer Butter Masala", isVeg: true, price: 239 },
          { name: "Kaju Paneer Curry", isVeg: true, price: 269 },
          { name: "Palak Paneer", isVeg: true, price: 219 },
        ],
      },
      {
        id: "non-veg-main-course",
        name: "Non Veg Main Course",
        items: [
          { name: "Egg Bhurji", isVeg: false, price: 129 },
          { name: "Egg Curry", description: "Delicious egg curry with 3 eggs", isVeg: false, price: 149 },
          { name: "Chicken Afghani", isVeg: false, price: 289 },
          { name: "Chicken Angara", isVeg: false, price: 299 },
          { name: "Chicken Do Pyaaza", isVeg: false, price: 279 },
          { name: "Kaju Chicken Curry", isVeg: false, price: 319 },
          { name: "Chicken Curry", isVeg: false, price: 249 },
          { name: "Chicken Masala Curry", isVeg: false, price: 269 },
          { name: "Butter Chicken", isVeg: false, price: 289 },
          { name: "Chicken Tikka Masala", isVeg: false, price: 299 },
          { name: "Murgh Masala Curry", isVeg: false, price: 279 },
          { name: "Chicken Boneless Curry", isVeg: false, price: 289 },
          { name: "Chicken Mughlai Curry", isVeg: false, price: 299 },
          { name: "Methi Chicken", isVeg: false, price: 279 },
          { name: "Fish Curry", isVeg: false, price: 329 },
        ],
      },
    ],
  },
  {
    id: "breads",
    name: "Breads",
    categories: [
      {
        id: "breads-all",
        name: "Indian Breads",
        items: [
          { name: "Plain Roti", isVeg: true, price: 25 },
          { name: "Plain Naan", isVeg: true, price: 45 },
          { name: "Butter Naan", isVeg: true, price: 55 },
          { name: "Butter Roti", isVeg: true, price: 35 },
          { name: "Garlic Naan", isVeg: true, price: 65 },
          { name: "Pulka", isVeg: true, price: 20 },
          { name: "Kulcha", isVeg: true, price: 55 },
          { name: "Chapati", isVeg: true, price: 20 },
        ],
      },
    ],
  },
  {
    id: "rice-biryani",
    name: "Rice and Biryani",
    categories: [
      {
        id: "rice",
        name: "Rice",
        items: [
          { name: "Curd Rice", isVeg: true, price: 99 },
        ],
      },
      {
        id: "veg-biryani",
        name: "Veg Biryani",
        items: [
          { name: "Veg Biryani", isVeg: true, price: 179 },
          { name: "Paneer Biryani", isVeg: true, price: 219 },
          { name: "Mushroom Biryani", isVeg: true, price: 209 },
        ],
      },
      {
        id: "non-veg-biryani",
        name: "Non Veg Biryani",
        items: [
          { name: "Egg Biryani", description: "Delicious biryani with 3 eggs", isVeg: false, price: 169 },
          { name: "Chicken Dum Biryani (Mini)", isVeg: false, price: 179 },
          { name: "Chicken Dum Biryani", isVeg: false, price: 249 },
          { name: "Chicken Fry Biryani", isVeg: false, price: 269 },
          { name: "Chicken Mughlai Biryani", isVeg: false, price: 289 },
          { name: "Chicken Tandoori Biryani", isVeg: false, price: 299 },
          { name: "Chicken Lollipop Biryani", isVeg: false, price: 309 },
          { name: "Chicken Tikka Biryani", isVeg: false, price: 299 },
          { name: "Chicken Boneless Biryani", isVeg: false, price: 279 },
          { name: "Fish Biryani", isVeg: false, price: 329 },
          { name: "Prawns Biryani", isVeg: false, price: 379 },
        ],
      },
    ],
  },
  {
    id: "fried-rice-noodles",
    name: "Fried Rice and Noodles",
    categories: [
      {
        id: "veg-fried-rice",
        name: "Veg Fried Rice",
        items: [
          { name: "Veg Fried Rice", isVeg: true, price: 149 },
          { name: "Veg Schezwan Fried Rice", isVeg: true, price: 169 },
          { name: "Paneer Fried Rice", isVeg: true, price: 189 },
          { name: "Veg Mixed Fried Rice", isVeg: true, price: 179 },
          { name: "Paneer Mushroom Fried Rice", isVeg: true, price: 199 },
          { name: "Kaju Fried Rice", isVeg: true, price: 209 },
        ],
      },
      {
        id: "non-veg-fried-rice",
        name: "Non Veg Fried Rice",
        items: [
          { name: "Egg Fried Rice", isVeg: false, price: 159 },
          { name: "Chicken Fried Rice", isVeg: false, price: 189 },
          { name: "Chicken Schezwan Fried Rice", isVeg: false, price: 209 },
          { name: "Prawns Fried Rice", isVeg: false, price: 269 },
          { name: "Non Veg Mixed Fried Rice", isVeg: false, price: 229 },
        ],
      },
      {
        id: "veg-noodles",
        name: "Veg Noodles",
        items: [
          { name: "Veg Noodles", isVeg: true, price: 149 },
          { name: "Veg Schezwan Noodles", isVeg: true, price: 169 },
          { name: "Veg Hakka Noodles", isVeg: true, price: 159 },
          { name: "Gobi Noodles", isVeg: true, price: 169 },
          { name: "Veg Mixed Noodles", isVeg: true, price: 179 },
        ],
      },
      {
        id: "non-veg-noodles",
        name: "Non Veg Noodles",
        items: [
          { name: "Egg Noodles", isVeg: false, price: 159 },
          { name: "Chicken Hakka Noodles", isVeg: false, price: 199 },
          { name: "Chicken Schezwan Noodles", isVeg: false, price: 219 },
        ],
      },
    ],
  },
  {
    id: "snacks",
    name: "Snacks",
    categories: [
      {
        id: "snacks-all",
        name: "Quick Bites",
        items: [
          { name: "Egg Omelette", isVeg: false, price: 59 },
        ],
      },
    ],
  },
]

// Get total item count
export function getTotalMenuItems(): number {
  return menuData.reduce((total, section) => {
    return total + section.categories.reduce((catTotal, category) => {
      return catTotal + category.items.length
    }, 0)
  }, 0)
}

// Get items by section
export function getMenuSection(sectionId: string): MenuSection | undefined {
  return menuData.find(section => section.id === sectionId)
}
